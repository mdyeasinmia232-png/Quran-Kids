# Quran Kids — Android Studio প্রজেক্ট

এটি Quran Kids-এর প্রাথমিক Android Studio প্রজেক্ট। অ্যাপটি একটি স্থানীয় HTML শেখার ইন্টারফেস Android WebView-তে দেখায়।

## চালানোর নিয়ম
1. ZIP ফাইলটি Extract করুন।
2. Android Studio খুলে `QuranKids` ফোল্ডারটি Open করুন।
3. Gradle sync সম্পন্ন হতে দিন।
4. Android SDK 35 ইনস্টল না থাকলে SDK Manager থেকে ইনস্টল করুন।
5. Run চাপুন অথবা Build > Build Bundle(s) / APK(s) থেকে APK তৈরি করুন।

## গুরুত্বপূর্ণ সীমাবদ্ধতা
- এটি প্রাথমিক কার্যকর প্রজেক্ট কাঠামো; Google Play-এ প্রকাশের জন্য প্রস্তুত পূর্ণাঙ্গ কুরআন অ্যাপ নয়।
- বর্তমানে নূরানী কায়দার নমুনা ও সূরার তালিকা আছে। পূর্ণ কায়দা, সম্পূর্ণ ৩০ পারা/১১৪ সূরার যাচাইকৃত আরবি পাঠ, অনুবাদ, অডিও ও শব্দ/আয়াত-ভিত্তিক অডিও এখনো যুক্ত করা হয়নি।
- বাংলা উচ্চারণ আরবি মাখরাজের বিকল্প নয়। নির্ভুলতা যোগ্য কুরআন শিক্ষক/কারি দিয়ে যাচাই করতে হবে।
- কুরআনের টেক্সট, অনুবাদ, অডিও ও কায়দার বইয়ের কপিরাইট/ব্যবহারের অনুমতি নিশ্চিত করতে হবে।
- Play Store প্রকাশের আগে privacy policy, content rating, target audience, data safety, testing এবং Google Play নীতিমালা পূরণ করতে হবে।
- প্রকল্পটি Android Studio-তে Gradle দিয়ে build করতে হবে; এই পরিবেশে APK compile করা হয়নি।


## GitHub Actions দিয়ে APK/AAB build
1. GitHub-এ একটি নতুন repository তৈরি করে এই প্রজেক্টের সব ফাইল upload/push করুন।
2. `Actions` ট্যাবে গিয়ে `Build Quran Kids Android` workflow চালান (অথবা `main` branch-এ push করুন)।
3. Workflow সফল হলে `quran-kids-build` artifact থেকে debug APK ও unsigned release AAB পাওয়া যাবে।
4. Play Store-এ প্রকাশের আগে release AAB-কে নিজের Play App Signing/keystore ব্যবস্থায় স্বাক্ষর করতে হবে এবং Play Console-এর সব ধাপ সম্পন্ন করতে হবে।
